import tkinter as tk
from tkinter import messagebox
import webbrowser
from PIL import ImageTk, Image

class LotChangeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lot Change Request")
        self.root.iconbitmap(r"C:\Users\jp462\OneDrive\Desktop\IVYTECH\PYTHON\M06\sticky_notes_icon_259264.ico")
        self.root.geometry("500x500")

        # Load the image
        image_path = "C:/Users/jp462/OneDrive/Desktop/IVYTECH/PYTHON/M08/paper_2.jpg"
        self.image = Image.open(image_path)
        self.image = self.image.resize((100, 100))
        self.photo = ImageTk.PhotoImage(self.image)

        # Create the "Change Lot" button with image
        self.button_change_lot = tk.Button(root, text="Change Lot", compound="left", image=self.photo, command=self.change_lot)
        self.button_change_lot.pack(pady=50)

        # Create a frame to organize the layout
        self.frame = tk.Frame(root)

    def change_lot(self):
        response = messagebox.askyesno("Confirmation", "Are you sure the item number on the new DHR match the item number on the old DHR?")

        if response:
            messagebox.showinfo("Lot Change", "Proceeding to Forms.")
            self.open_forms_page()
        else:
            messagebox.showinfo("Lot Change", "Different item numbers usually mean different material or packaging.  Please check both DHRs before proceeding.")

    def open_forms_page(self):
        # Open Hyperlinks for Operator
        webbrowser.open("file:///path/to/forms_page.html")

class LotCloseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lot Close Request")
        self.root.iconbitmap(r"C:\Users\jp462\OneDrive\Desktop\IVYTECH\PYTHON\M06\sticky_notes_icon_259264.ico")
        self.root.geometry("500x500")

        # Load the image
        image_path = "C:/Users/jp462/OneDrive/Desktop/IVYTECH/PYTHON/M08/43624.jpg"
        self.image = Image.open(image_path)
        self.image = self.image.resize((100, 100))
        self.photo = ImageTk.PhotoImage(self.image)
        

        # Create the "Close Lot" button with image
        self.button_close_lot = tk.Button(root, text="Close Lot", compound="left", image=self.photo, command=self.close_lot)
        self.button_close_lot.pack(pady=50)

        # Create a frame to organize the layout
        self.frame = tk.Frame(root)

    def close_lot(self):
        response = messagebox.askyesno("Confirmation", "Is there any heldware in your current order that needs to be remade?")

        if response:
            messagebox.showinfo("Lot Close", "If there is any Heldware documented in your 'Label Control Record' page, please see a Quality Tech before closing current order.")
            
        else:
            messagebox.showinfo("Lot Close", "Opening Forms.")
            self.open_forms_page()

    def open_forms_page(self):
        # Open Hyperlinks for Operator
        webbrowser.open("file:///path/to/forms_page.html")

def main():
    root = tk.Tk()

    # Create instances of both apps
    app_change = LotChangeApp(root)
    app_close = LotCloseApp(root)

    # Pack the frames into the root window
    app_change.frame.pack(side=tk.LEFT, padx=10)
    app_close.frame.pack(side=tk.LEFT, padx=10)

    root.mainloop()

if __name__ == "__main__":
    main()
